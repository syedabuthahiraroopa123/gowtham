

function validate()
{
const user = document.getElementById("user").value;
const pass = document.getElementById("pass").value;
console.log(pass);

let v;
if(pass.length<8)
{
     v="password must be greater than 8"
    document.getElementById('details').innerHTML=v;
}
else{
    v="";
    document.getElementById('details').innerHTML=v;
}
 if (user == "") {
   document.getElementById("user-validation").innerHTML ="Username should not be empty";
 } else {
   document.getElementById("user-validation").innerHTML = "";
 }


}
