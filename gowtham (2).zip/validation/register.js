function validate()
{
  const user=document.getElementById("user").value ;
  const password1 = document.getElementById("pass1").value;
  const password2 = document.getElementById("pass2").value;
  const email = document.getElementById("email").value;
  const number = parseInt(document.getElementById("no").value);

  
  if(user=="")
  {
    document.getElementById("user-validation").innerHTML="Username should not be empty";
  }
  else
  {
     document.getElementById("user-validation").innerHTML ="";
       
  }
    
  

  if(isNaN(number))
  {
     document.getElementById("number-validation").innerHTML ="Enter numberic values only";
  }
  else{
     document.getElementById("number-validation").innerHTML ="";
  }



  if(password1!=password2)
  {
     document.getElementById('pass-match').innerHTML="Both passwords must be same";
  }
  else{
     document.getElementById("pass-match").innerHTML ="";
      
  }
  if(password1.length<8)
  {
    document.getElementById('pass-details').innerHTML="Password must be greater than 8";
  }
  else{
    document.getElementById("pass-details").innerHTML="";
  }




 
var atposition=email.indexOf("@")+1;  
var dotposition=email.lastIndexOf(".")+1;  
console.log(atposition);
console.log(dotposition);
if (atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length)
{  
      document.getElementById("email-validation").innerHTML="Please enter a valid e-mail address ";
}
else{
    document.getElementById("email-validation").innerHTML="";
}
  
}